#Implement a python code to add 3 numbers using a) CLA b) CLI c) LIST d) DICTIONARY e)LAMDA FUNCTION f) NORMAL FUNCTION g) * args h) **kwargs

#/usr/bin/python3

#from CLA
import sys

sum=0
sum=int(sys.argv[1])+int(sys.argv[2])+int(sys.argv[3])
print("the sum from CLA is:"+str(sum))

#from CLI

#from list

list=[1,2,3]
sum1=list[0]+list[1]+list[2]
print("sum from list is:",str(sum1))

#from dictionary

dict={'key1':'3','key2':'4','key3':'5'}
a=int(dict['key1'])+int(dict['key2'])+int(dict['key3'])
print("the result of adding values from dictionary is ",a)

#Lamda function

for i in (1, 2, 3):
   a =  lambda x: x + x
print("sum using lamda function is")
print (a(i))

# using normal functions

def add(a,b,c):   
    return a + b +c
print("this is adding numbers using normal functions")
print ("enter the first number")
a = int(input("First no: "))
print ("enter the second number")
b = int(input("Second no: "))
print ("enter the third number")
c = int(input("third no: "))
result = add(a, b, c)

print ("The result got using normal function is: %r." % result)

#using *args

def add_args(f_arg, *argv):
	sum5=f_arg
	for arg in argv:
		sum5=sum5+int(arg)	       
	print('The result of args is',sum5)
res=add_args(3,3,3)


#using **kwargs
def add_kwargs(**kwargs):
	sum6=0
	for key, value in kwargs.items():
		sum6=sum6+int(value)		
	print('The result of kwargs',sum6)

add_kwargs(a=3,b=3,c=3)
	


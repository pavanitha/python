# Implement a python code for menu driven python code for arithmetic operations. [use case type statement using functions]

#!/usr/bin/python

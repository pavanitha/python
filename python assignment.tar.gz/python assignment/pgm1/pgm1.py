#Implement a python code to say “Hello <name>.The name is passed from the user as a) CLA  b) CLI

#/usr/bin/python
import sys
#name=input("enter name\n")
name=(sys.argv[1])
print ("Hello "+str(name))
